package logica;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Logica {

    public Logica(){
    }

    public int sumar(int i, int j){
        return (i+j);
    }

    public int restar(int i, int j){
        return (i-j);
    }

}
